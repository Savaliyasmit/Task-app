//
//  alert.swift
//  TodoApp
//



import UIKit

class AlertUtility {
    
    // Static function to show alert
    static func showAlert(from vc: UIViewController, title: String, message: String, confirmActionTitle: String, confirmStyle: UIAlertAction.Style, confirmAction: @escaping () -> Void, cancelActionTitle: String = "Cancel") {
        
        // Create the alert controller
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        // Add the confirm action
        let confirm = UIAlertAction(title: confirmActionTitle, style: confirmStyle) { _ in
            confirmAction()
        }
        alert.addAction(confirm)
        
        // Add the cancel action
        let cancel = UIAlertAction(title: cancelActionTitle, style: .cancel, handler: nil)
        alert.addAction(cancel)
        
        // Present the alert
        vc.present(alert, animated: true, completion: nil)
    }
}


func showAlertWithTextField(from vc: UIViewController) {
    // Step 1: Create the alert controller
    let alertController = UIAlertController(title: "Enter Value", message: nil, preferredStyle: .alert)
    
    // Step 2: Add a text field to the alert
    alertController.addTextField { textField in
        textField.placeholder = "Enter some text"
    }
    
    alertController.addTextField { textField in
        textField.placeholder = "Enter some text"
    }
    // Step 3: Add an "Add" action to capture the text field value
    let addAction = UIAlertAction(title: "Add", style: .default) { _ in
        // Capture the value from the text field
        if let textField = alertController.textFields?.first, let text = textField.text {
            print("Value entered: \(text)")
            // Do something with the entered text
        }
    }
    
    // Step 4: Add a "Cancel" action
    let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
    
    // Step 5: Add actions to the alert controller
    alertController.addAction(addAction)
    alertController.addAction(cancelAction)
    
    // Step 6: Present the alert controller
    vc.present(alertController, animated: true, completion: nil)
}


class Stroage{
    private var store:[String:String]
    
    init(store: [String : String] = [:]) {
        self.store = store
    }
      func add(title:String , value:String){
        store[title] = value
    }
    
    func get(_ title:String) -> String{
        return store[title] ?? ""
    }
    
     func remove(_ title:String) {
        store.removeValue(forKey: title)
    }
    
     func update(_ oldTitle:String , newTitle:String){
        if let title = store[oldTitle] {
            store.removeValue(forKey: title )
            store[newTitle] = title
        }
    }
    
}

enum UniqueKey:String{
    case TodoList = "TodoList"
    case list = "list"
    
}

func delay(time:TimeInterval    , completion:@escaping () -> Void){
    DispatchQueue.main.asyncAfter(deadline: .now() + time){
        completion()
    }
}



private var debounceTimer: Timer?

func debounce(timeInterval: TimeInterval, action: @escaping () -> Void) {
    // Invalidate any existing timer
    debounceTimer?.invalidate()
    
    // Schedule a new timer
    debounceTimer = Timer.scheduledTimer(withTimeInterval: timeInterval, repeats: false) { _ in
        action()
    }
}
 



var isOnboarding:Bool {
    get{
        return UserDefaults.standard.bool(forKey: "isOnboardingComplate")
    }
    set{
        UserDefaults.standard.setValue(newValue, forKey: "isOnboardingComplate" )
        UserDefaults.standard.synchronize()
    }
}

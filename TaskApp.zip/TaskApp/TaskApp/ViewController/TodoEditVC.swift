//
//  TodoEditVC.swift
//  TodoApp
//
//  Created by smit on 07/10/24.
//

import UIKit
import IQKeyboardManagerSwift

var tasks:[String:String]    {
    get{
        return UserDefaults.standard.dictionary(forKey: UniqueKey.list.rawValue) as? [String:String] ?? [:]
    }
    set{
        UserDefaults.standard.set(newValue, forKey: UniqueKey.list.rawValue)
    }
}

class TodoEditVC: UIViewController {
     
    @IBOutlet weak var txtViewTask: UITextView!
    @IBOutlet weak var lblTitle: UILabel!
    
    var recivedTask:String?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTitle()
        showSavedTasks()
    }
   
    override func viewWillAppear(_ animated: Bool) {
        HomeVC().sercheCtr.isActive = false
    }
    
    
    @IBAction func backToHomeBtn(_ sender: Any) {
        self.view.endEditing(true)
        var addTask = tasks
        addTask[recivedTask ?? ""] = txtViewTask.text ?? ""
        tasks = addTask
        print(addTask)
        self.navigationController?.popViewController(animated: true)
    }
    
    func setupTitle(){
        if let title = recivedTask, title.count > 5 {
            lblTitle.text = "\(String(title.prefix(5)))... "
           } else {
               lblTitle.text = recivedTask
           }
        }
    
    func showSavedTasks(){
        let currentTasks = tasks[recivedTask ?? ""]
        txtViewTask.text = currentTasks
    }
    
    
}


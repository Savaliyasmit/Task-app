//
//  SplashVC.swift
//  TodoApp
//
//  Created by smit on 15/10/24.
//

import UIKit

 class SplashVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navToMain()
    }
    
    private func navToMain(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 3){
            if isOnboarding {
                guard let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC") as? HomeVC else {
                    return
                }
                self.navigationController?.pushViewController(vc, animated: true)
            }else{
                guard let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "OnBoardingVC") as? OnBoardingVC else {
                    return
                }
                //            self.present(vc, animated: true)
                //            self.navigationController?.present(vc, animated: true)
                self.navigationController?.pushViewController(vc, animated: true)
            }}
    }

}

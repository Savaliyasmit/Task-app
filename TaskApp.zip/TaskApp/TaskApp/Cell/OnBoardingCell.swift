//
//  OnBoardingCellCollectionViewCell.swift
//  TodoApp
//
//  Created by smit on 24/10/24.
//

import UIKit

class OnBoardingCell: UICollectionViewCell {

    @IBOutlet weak var imgOnBoarding: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    
    }

}

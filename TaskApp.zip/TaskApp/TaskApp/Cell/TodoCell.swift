        //
        //  TodoCell.swift
        //  TodoApp
        //
        //  Created by smit on 30/09/24.
        //

        import UIKit

        class TodoCell: UITableViewCell {

//            var buttonTap:(()->Void)?
            
            @IBOutlet weak var lblTask: UILabel!
            
            @IBOutlet weak var lblCreatedAt: UILabel!
            
            //            @IBAction func btnNav(_ sender: UIButton) {
//                UIView.animate(withDuration: 0.3){
//                    sender.backgroundColor = .gray.withAlphaComponent(0.2)
//                }completion: { finish in
//                    if(finish){
//                        UIView.animate(withDuration: 0.3){
//                            sender.backgroundColor = .clear
//                        }
//                    }
//                }
//                buttonTap?()        
//            }
//            
            override func awakeFromNib() {
                super.awakeFromNib()
                lblTask.numberOfLines = 0
                lblTask.lineBreakMode = .byWordWrapping
                self.selectionStyle = .none
            }

            
        }
